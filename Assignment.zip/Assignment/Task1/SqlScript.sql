use db_hospital;
GO

-- remove existing table
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_patient')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_patient
END
GO

BEGIN
IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_patient_audit')
	DROP TABLE db_hospital.dbo.tbl_patient_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom_group')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom_group
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom_group_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom_group_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy_symptom_group')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy_symptom_group
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy_symptom_group_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy_symptom_group_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom_group_list')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom_group_list
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_symptom_group_list_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_symptom_group_list_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy_fatality_checking')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy_fatality_checking
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_allergy_fatality_checking_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_allergy_fatality_checking_audit
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_patient_allergy')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_patient_allergy
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = 'db_hospital' AND TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'tbl_patient_allergy_audit')
BEGIN
	DROP TABLE db_hospital.dbo.tbl_patient_allergy_audit
END
GO

---- main table
-- tbl_patient
CREATE TABLE db_hospital.dbo.tbl_patient (
id INT IDENTITY(1,1) UNIQUE,
patient_id VARCHAR(100) NOT NULL,
patient_name VARCHAR(200),
nric VARCHAR(100) UNIQUE NOT NULL,
age INT NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy
CREATE TABLE db_hospital.dbo.tbl_allergy (
id INT IDENTITY(1,1) UNIQUE,
allergy_id VARCHAR(100) UNIQUE NOT NULL,
allergy_name VARCHAR(200) NOT NULL,
allergy_desc VARCHAR(300) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom
CREATE TABLE db_hospital.dbo.tbl_symptom (
id INT IDENTITY(1,1) UNIQUE,
symptom_id VARCHAR(100) NOT NULL,
symptom_name VARCHAR(200) NOT NULL,
symptom_desc VARCHAR(300) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom_group
CREATE TABLE db_hospital.dbo.tbl_symptom_group (
id INT IDENTITY(1,1) UNIQUE,
symptom_group_id VARCHAR(100) NOT NULL,
symptom_group_name VARCHAR(200) NOT NULL,
symptom_group_desc VARCHAR(300) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy_symptom_group
CREATE TABLE db_hospital.dbo.tbl_allergy_symptom_group (
id INT IDENTITY(1,1) UNIQUE,
allergy_symptom_group_id VARCHAR(100) NOT NULL,
allergy_id VARCHAR(100) NOT NULL,
symptom_group_id VARCHAR(100) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom_group_list
CREATE TABLE db_hospital.dbo.tbl_symptom_group_list(
id INT IDENTITY(1,1) UNIQUE,
symptom_group_id VARCHAR(100) NOT NULL, 
symptom_id VARCHAR(100) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy_fatality_checking
create table db_hospital.dbo.tbl_allergy_fatality_checking
(
id INT IDENTITY(1,1) UNIQUE,
allergy_symptom_group_id VARCHAR(100) NOT NULL,
checking varbinary(700) NOT NULL,
fatality_level char(1) NOT NULL, -- N=no,L=low,M=medium,H=high
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_patient_allergy
CREATE TABLE db_hospital.dbo.tbl_patient_allergy (
id INT IDENTITY(1,1) UNIQUE,
patient_id VARCHAR(100) NOT NULL,
allergy_id VARCHAR(100) NOT NULL,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

---- create audit table
-- tbl_patient_audit
CREATE TABLE db_hospital.dbo.tbl_patient_audit (
id INT,
patient_id VARCHAR(100),
patient_name VARCHAR(200),
nric VARCHAR(100),
age INT,
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy_audit
CREATE TABLE db_hospital.dbo.tbl_allergy_audit (
id INT,
allergy_id VARCHAR(100),
allergy_name VARCHAR(200),
allergy_desc VARCHAR(300),
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom_audit
CREATE TABLE db_hospital.dbo.tbl_symptom_audit (
id INT,
symptom_id VARCHAR(100),
symptom_name VARCHAR(200),
symptom_desc VARCHAR(300),
last_updated_dt datetime default GETDATE(),
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom_group_audit
CREATE TABLE db_hospital.dbo.tbl_symptom_group_audit (
id INT,
symptom_group_id VARCHAR(100),
symptom_group_name VARCHAR(200),
symptom_group_desc VARCHAR(300),
last_updated_dt datetime,
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy_symptom_group_audit
CREATE TABLE db_hospital.dbo.tbl_allergy_symptom_group_audit (
id INT,
allergy_symptom_group_id VARCHAR(100),
allergy_id VARCHAR(100),
symptom_group_id VARCHAR(100),
last_updated_dt datetime,
last_updated_by VARCHAR(200)
)
GO

-- tbl_symptom_group_list_audit
CREATE TABLE db_hospital.dbo.tbl_symptom_group_list_audit(
id INT,
symptom_group_id VARCHAR(100), 
symptom_id VARCHAR(100),
last_updated_dt datetime,
last_updated_by VARCHAR(200)
)
GO

-- tbl_allergy_fatality_checking_audit
create table db_hospital.dbo.tbl_allergy_fatality_checking_audit
(
id INT,
allergy_symptom_group_id VARCHAR(100),
checking varbinary(700),
fatality_level char(1), -- N=no,L=low,M=medium,H=high
last_updated_dt datetime,
last_updated_by VARCHAR(200)
)
GO

-- tbl_patient_allergy_audit
CREATE TABLE db_hospital.dbo.tbl_patient_allergy_audit (
id INT,
patient_id VARCHAR(100),
allergy_id VARCHAR(100),
last_updated_dt datetime,
last_updated_by VARCHAR(200)
)
GO

-- create trigger for audit table action
-- tbl_patient
CREATE TRIGGER trg_tbl_patient
ON db_hospital.dbo.tbl_patient
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_patient_audit
(id,patient_id,patient_name,nric,age,last_updated_dt,last_updated_by)
SELECT id,patient_id,patient_name,nric,age,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_allergy
CREATE TRIGGER trg_tbl_allergy
ON db_hospital.dbo.tbl_allergy
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_allergy_audit
(id,allergy_id,allergy_name,allergy_desc,last_updated_dt,last_updated_by)
SELECT id,allergy_id,allergy_name,allergy_desc,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_symptom
CREATE TRIGGER trg_tbl_symptom
ON db_hospital.dbo.tbl_symptom
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_symptom_audit
(id,symptom_id,symptom_name,symptom_desc,last_updated_dt,last_updated_by)
SELECT id,symptom_id,symptom_name,symptom_desc,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_symptom_group
CREATE TRIGGER trg_tbl_symptom_group
ON db_hospital.dbo.tbl_symptom_group
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_symptom_group_audit
(id,symptom_group_id,symptom_group_name,symptom_group_desc,last_updated_dt,last_updated_by)
SELECT id,symptom_group_id,symptom_group_name,symptom_group_desc,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_allergy_symptom_group
CREATE TRIGGER trg_tbl_allergy_symptom_group
ON db_hospital.dbo.tbl_allergy_symptom_group
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_allergy_symptom_group_audit
(id,allergy_symptom_group_id,allergy_id,symptom_group_id,last_updated_dt,last_updated_by)
SELECT id,allergy_symptom_group_id,allergy_id,symptom_group_id,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_allergy_fatality_checking
CREATE TRIGGER trg_tbl_allergy_fatality_checking
ON db_hospital.dbo.tbl_allergy_fatality_checking
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_allergy_fatality_checking_audit
(id,allergy_symptom_group_id,checking,fatality_level,last_updated_dt,last_updated_by)
SELECT id,allergy_symptom_group_id,checking,fatality_level,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- tbl_symptom_group_list
CREATE TRIGGER trg_tbl_symptom_group_list
ON db_hospital.dbo.tbl_symptom_group_list
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_symptom_group_list_audit
(id,symptom_group_id,symptom_id,last_updated_dt,last_updated_by)
SELECT id,symptom_group_id,symptom_id,last_updated_dt,last_updated_by FROM INSERTED;
END
GO 

-- tbl_patient_allergy
CREATE TRIGGER trg_tbl_patient_allergy
ON db_hospital.dbo.tbl_patient_allergy
AFTER INSERT, UPDATE
AS
BEGIN
INSERT INTO db_hospital.dbo.tbl_patient_allergy_audit
(id,patient_id,allergy_id,last_updated_dt,last_updated_by)
SELECT id,patient_id,allergy_id,last_updated_dt,last_updated_by FROM INSERTED;
END
GO

-- create index
CREATE UNIQUE CLUSTERED INDEX tbl_patient_index
ON db_hospital.dbo.tbl_patient (patient_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_allergy_index
ON db_hospital.dbo.tbl_allergy (allergy_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_symptom_index
ON db_hospital.dbo.tbl_symptom (symptom_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_symptom_group_index
ON db_hospital.dbo.tbl_symptom_group (symptom_group_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_allergy_symptom_group_index
ON db_hospital.dbo.tbl_allergy_symptom_group (allergy_symptom_group_id,allergy_id,symptom_group_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_symptom_group_list_index
ON db_hospital.dbo.tbl_symptom_group_list (symptom_group_id,symptom_id);
GO

CREATE UNIQUE CLUSTERED INDEX tbl_allergy_fatality_checking_index
ON db_hospital.dbo.tbl_allergy_fatality_checking (allergy_symptom_group_id,checking);
go

CREATE UNIQUE CLUSTERED INDEX tbl_patient_allergy_index
ON db_hospital.dbo.tbl_patient_allergy (patient_id,allergy_id);
GO

-- tbl_patient
INSERT INTO db_hospital.dbo.tbl_patient 
(patient_id,patient_name,nric,age,last_updated_dt,last_updated_by)
values 
('PATIENT_01','Citrus Lim','960903-07-5537',53,GETDATE(),'system');
go

-- tbl_allergy
insert into db_hospital.dbo.tbl_allergy
(allergy_id,allergy_name,allergy_desc,last_updated_dt,last_updated_by)
values
('FLOWER_ALLERGY','Flower Allergy','Nose allergy to powder like substance',GETDATE(),'system');
go

-- tbl_symptom
insert into db_hospital.dbo.tbl_symptom
(symptom_id,symptom_name,symptom_desc,last_updated_dt,last_updated_by)
values
('RUNNY_NOSE','Runny Nose','Nose is runny',GETDATE(),'system');
go
insert into db_hospital.dbo.tbl_symptom
(symptom_id,symptom_name,symptom_desc,last_updated_dt,last_updated_by)
values
('HIGH_FEVER','High Fever','Head temperature is higher than regular',GETDATE(),'system');

go

-- tbl_symptom_group
insert into db_hospital.dbo.tbl_symptom_group
(symptom_group_id,symptom_group_name,symptom_group_desc,last_updated_dt,last_updated_by)
values
('FLOWER_ALLERGY_SYMPTOM_GROUP', 'FLOWER_ALLERGY','allergy to flower',GETDATE(),'system');
go

-- tbl_symptom_group_list
insert into db_hospital.dbo.tbl_symptom_group_list
(symptom_group_id,symptom_id,last_updated_dt,last_updated_by)
values 
('FLOWER_ALLERGY_SYMPTOM_GROUP','RUNNY_NOSE',GETDATE(),'system');
insert into db_hospital.dbo.tbl_symptom_group_list
(symptom_group_id,symptom_id,last_updated_dt,last_updated_by)
values 
('FLOWER_ALLERGY_SYMPTOM_GROUP','HIGH_FEVER',GETDATE(),'system');

-- tbl_allergy_symptom_group
insert into db_hospital.dbo.tbl_allergy_symptom_group
(allergy_symptom_group_id,allergy_id,symptom_group_id,last_updated_dt,last_updated_by)
values 
('FLOWER_ALLERGY_GROUP','FLOWER_ALLERGY','FLOWER_ALLERGY_SYMPTOM_GROUP',GETDATE(),'system');

-- tbl_allergy_fatality_stage_checking
insert into db_hospital.dbo.tbl_allergy_fatality_checking
(allergy_symptom_group_id,checking,fatality_level,last_updated_dt,last_updated_by)
values
('FLOWER_ALLERGY_GROUP',CAST('head_temperature=between37and39,blood_pressure=between110and120' AS varbinary(max)),'N',GETDATE(),'system');
GO

-- tbl_patient_allergy
insert into db_hospital.dbo.tbl_patient_allergy
(patient_id,allergy_id,last_updated_dt,last_updated_by)
values
('PATIENT_01','FLOWER_ALLERGY',GETDATE(),'system');
GO
